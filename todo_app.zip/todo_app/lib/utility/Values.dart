import 'package:todo_app/dataBase/dataManager/DataManager.dart';

class Values{

  //static final DataManager dataManager=DataManager.createDateManager();


}