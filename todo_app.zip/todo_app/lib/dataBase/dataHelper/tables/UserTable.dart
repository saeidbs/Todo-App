import 'package:todo_app/dataBase/dataHelper/tables/BaseTable.dart';

class UserTable with BaseTable{

static const String TABLE_NAME="user";
static const String EMAIL_COLUMN="email_user";
static const String PASSWORD_COLUMN="password_user";



}