abstract class BaseTable {

 String saeid = "_id";

}