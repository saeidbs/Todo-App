import 'dart:io';

import 'package:path_provider/path_provider.dart';
import 'package:sqflite/sqflite.dart';
import 'package:todo_app/dataBase/DatabaseHelper.dart';
import 'package:todo_app/dataBase/dao/TodoDAO.dart';

import 'dart:io';

import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';
import 'package:path_provider/path_provider.dart';
import 'package:todo_app/dataBase/dataHelper/tables/TodoTable.dart';

class DataManager{
  static final _databaseName = "MyDatabase.db";
  static final _databaseVersion = 1;

  DataManager._();
  static final DataManager dataManger= DataManager._();
  static  Database _database;

  TodoDAO _todoDAO;


  Future<Database> get database async {
  print("ghable null");
    if (_database != null) return _database;
     //lazily instantiate the db the first time it is accessed
  print("null bod");
    _database = await _initDatabase();
    return _database;

  }

  // this opens the database (and creates it if it doesn't exist)
  _initDatabase() async {
    Directory documentsDirectory = await getApplicationDocumentsDirectory();
    String path = join(documentsDirectory.path, _databaseName);
    return await openDatabase(path,
        version: _databaseVersion,
        onCreate: _onCreate);
  }

  // SQL code to create the database table
  Future _onCreate(Database db, int version) async {
    await db.execute(TodoTable.getCreateTableString());

    print("samadi");

    _initial();
  }


  Future _initial()  async {
    _todoDAO=TodoDAO(DB: await database);

  }

  TodoDAO getTodoDAO(){
    return _todoDAO;
  }

//
//   DataManager()   {
////    DataBaseHandler dataBaseHandler=DataBaseHandler();
////    _db= await dataBaseHandler.database;
////    _initial();
//   saeid();
//  }
//
//  saeid() async {
//    DataBaseHandler dataBaseHandler=DataBaseHandler();
//    _database= await dataBaseHandler.database;
//    _initial();
//  }
//
//
//  void _initial(){
//    _todoDAO=TodoDAO(DB: _database);
//
//  }
//
//TodoDAO getTodoDAO()=>_todoDAO;
//
//   static DataManager createDateManager() {
//    if (_dataManger == null)
//     _dataManger = DataManager();
//
//
//    return _dataManger;
//  }
}